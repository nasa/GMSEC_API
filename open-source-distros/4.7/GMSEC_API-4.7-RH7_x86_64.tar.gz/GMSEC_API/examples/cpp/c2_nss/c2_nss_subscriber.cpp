/*
 * Copyright 2007-2020 United States Government as represented by the
 * Administrator of The National Aeronautics and Space Administration.
 * No copyright is claimed in the United States under Title 17, U.S. Code.
 * All Rights Reserved.
 */

#include <gmsec4_cpp.h>

#include <iostream>

using namespace gmsec::api;
using namespace gmsec::api::mist;
using namespace gmsec::api::mist::message;


void initializeLogging(Config& config);


int main(int argc, char** argv)
{
	if (argc <= 1)
	{
		std::cerr << "Usage: " << argv[0] << " mw-id=<middleware ID>" << std::endl;
		return -1;
	}

	//o Setup configuration with the supplied command line arguments
	Config config(argc, argv);

	//o Unless otherwise configured, setup configuration that allows us to
	//  log messages to stderr.
	initializeLogging(config);

	//o Display the version number of the GMSEC API
	GMSEC_INFO << ConnectionManager::getAPIVersion();

	//o Setup configuration with CompatC2 related options
	config.addValue("sec-policy",     "c2_nss");
	config.addValue("sec-nss-dir",    "nssdb");
	config.addValue("sec-nss-key",    "secret");
	config.addValue("sec-signer-key", "mycert");

	try
	{
		ConnectionManager connMgr(config);

		connMgr.initialize();

		connMgr.subscribe("GMSEC.>");

		GMSEC_INFO << "Waiting for message to be published...";

		Message* msg = connMgr.receive(-1);

		if (msg)
		{
			GMSEC_INFO << "Received:\n" << msg->toXML();

			connMgr.release(msg);
		}
		else
		{
			GMSEC_WARNING << "Timeout occurred; no message received.";
		}

		connMgr.cleanup();
	}
	catch (const Exception& e)
	{
		GMSEC_ERROR << "Exception: " << e.what();
	}
}


void initializeLogging(Config& config)
{
	const char* logLevel = config.getValue("loglevel");
	const char* logFile  = config.getValue("logfile");

	if (!logLevel)
	{
		config.addValue("loglevel", "info");
	}
	if (!logFile)
	{
		config.addValue("logfile", "stderr");
	}
}
