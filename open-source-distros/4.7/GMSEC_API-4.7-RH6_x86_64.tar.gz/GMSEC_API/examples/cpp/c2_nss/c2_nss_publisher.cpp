/*
 * Copyright 2007-2020 United States Government as represented by the
 * Administrator of The National Aeronautics and Space Administration.
 * No copyright is claimed in the United States under Title 17, U.S. Code.
 * All Rights Reserved.
 */

#include <gmsec4_cpp.h>

#include <iostream>

using namespace gmsec::api;
using namespace gmsec::api::mist;
using namespace gmsec::api::mist::message;
using namespace gmsec::api::util;


const char* const HB_MESSAGE_SUBJECT        = "GMSEC.MY-MISSION.MY-SAT-ID.MSG.HB.C2-NSS-PUBLISHER";
const char* const LEGACY_HB_MESSAGE_SUBJECT = "GMSEC.MY-MISSION.MY-SAT-ID.MSG.C2CX.C2-NSS-PUBLISHER.HB";


// Helper functions
void initializeLogging(Config& config);
MistMessage buildHeartbeatMessage(Specification& spec);
DataList<Field*> defineStandardFields(const Specification& spec);


int main(int argc, char** argv)
{
	if (argc <= 1)
	{
		std::cerr << "Usage: " << argv[0] << " mw-id=<middleware ID>" << std::endl;
		return -1;
	}

	//o Setup configuration with the supplied command line arguments
	Config config(argc, argv);

	//o Unless otherwise configured, setup configuration that allows us to
	//  log messages to stderr.
	initializeLogging(config);

	//o Display the version number of the GMSEC API
	GMSEC_INFO << ConnectionManager::getAPIVersion();

	//o Setup configuration with CompatC2 related options
	config.addValue("sec-policy",     "c2_nss");
	config.addValue("sec-nss-dir",    "nssdb");
	config.addValue("sec-nss-key",    "secret");
	config.addValue("sec-signer-key", "mycert");
	config.addValue("sec-auth-topic", "MY.AUTH.TOPIC");
	config.addValue("sec-auth-name",  "JohnDoe");

	try
	{
		ConnectionManager connMgr(config);

		connMgr.initialize();

		Message msg = buildHeartbeatMessage(connMgr.getSpecification());

		connMgr.publish(msg);

		GMSEC_INFO << "Published:\n" << msg.toXML();

		connMgr.cleanup();
	}
	catch (const Exception& e)
	{
		GMSEC_ERROR << "Exception: " << e.what();
	}
}


void initializeLogging(Config& config)
{
	const char* logLevel = config.getValue("loglevel");
	const char* logFile  = config.getValue("logfile");

	if (!logLevel)
	{
		config.addValue("loglevel", "info");
	}
	if (!logFile)
	{
		config.addValue("logfile", "stderr");
	}
}


MistMessage buildHeartbeatMessage(Specification& spec)
{
	DataList<Field*> standardFields = defineStandardFields(spec);

	MistMessage::setStandardFields(standardFields);

	const char* subject  = (spec.getVersion() >= GMSEC_ISD_2019_00 ? HB_MESSAGE_SUBJECT : LEGACY_HB_MESSAGE_SUBJECT);
	const char* schemaID = (spec.getVersion() >= GMSEC_ISD_2019_00 ? "MSG.HB" : "MSG.C2CX.HB");

	MistMessage msg(subject, schemaID, spec);

	MistMessage::clearStandardFields();

	return msg;
}


DataList<Field*> defineStandardFields(const Specification& spec)
{
	DataList<Field*> standardFields;

	standardFields.push_back(new StringField("COMPONENT", "PUBLISHER"));
	standardFields.push_back(new StringField("MISSION-ID", "MY-MISSION"));
	standardFields.push_back(new StringField("CONSTELLATION-ID", "MY-CONSTELLATION-ID"));
	standardFields.push_back(new StringField("SAT-ID-PHYSICAL", "MY-SAT-ID"));
	standardFields.push_back(new StringField("SAT-ID-LOGICAL", "MY-SAT-ID"));
	standardFields.push_back(new StringField("FACILITY", "MY-FACILITY"));

	if (spec.getVersion() == mist::GMSEC_ISD_2014_00)
	{
		standardFields.push_back(new StringField("MSG-ID", "MY-MSG-ID"));
	}
	else if (spec.getVersion() >= mist::GMSEC_ISD_2018_00)
	{
		standardFields.push_back(new StringField("DOMAIN1", "MY-DOMAIN-1"));
		standardFields.push_back(new StringField("DOMAIN2", "MY-DOMAIN-2"));
	}

	return standardFields;
}
