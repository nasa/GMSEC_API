class ExampleException extends Exception {
  public ExampleException(String msg) {
    super(msg);
  }
}
